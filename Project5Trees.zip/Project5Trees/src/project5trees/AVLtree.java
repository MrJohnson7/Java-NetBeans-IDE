/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description:
This class is extended from Comparable and can be used to build a binary
tree data structure. This class is able to compare what data is smaller and able
to place the data in appropriate positon. This tree also has to balance itself after 
a removal or new data inserted with the use of many different methods. 
*/
package project5trees;


public class AVLtree <T extends Comparable<T>>
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Node called root set to null, T called item not found
Inputs: Holds data that is passed to it
Outputs: Holds the data from the class
*/      
    ;
    private T ITEM_NOT_FOUND;
    public AVLnode<T> root = null;
    
/*
Function: insert
Author: Nicholas Johnson
Description: Inserts a AVLnode into the AVLtree
Inputs: T x and Node root are passed as parameters
Outputs: Node is placed in to data structure
*/        

    
    private void insert(T x, AVLnode<T> root)
    {
        if(root == null)
            root = new AVLnode(x, null, null);
        else if(x.compareTo(root.element) < 0)
        {
            insert(x, root.Aleft);
            if(height(root.Aleft) - height(root.Aright) == 2)
            {
                AVLnode<T> temp = root.Aleft;
                if(x.compareTo(temp.element) < 0)
                    rotateWithLeftChild(root);
            }
            else
                    doubleWithLeftChild(root);
            
        }
        else if(x.compareTo(root.element) > 0)
        {
            insert(x, root.Aright);
            if(height(root.Aright) - height(root.Aleft) == 2)
            {
                AVLnode<T> temp = root.Aright;
                if(x.compareTo(temp.element) > 0)
                        rotateWithRightChild(root);
            }
                else
                    doubleWithRightChild(root);
            
        }
        
        if(root!= null)
        {
            root.height = Math.max(height(root.Aleft), height(root.Aright)) + 1;
        }
            
    }
    
/*
Function: insert
Author: Nicholas Johnson
Description: Inserts a node
Inputs: T x is passed as a parameter
Outputs: Sends T x and the data section root to other insert method
*/
    
    public void insert(T x)
    {
       insert(x, this.root);
    }
    
/*
Function: printTree
Author: Nicholas Johnson
Description: Prints the data structure
Inputs:No inputs
Outputs: Sends the data section root to other printTree method
*/       
    
    public void printTree()
    {
        if(isEmpty())
            System.out.println("Empty Tree");
        else
            printTree(this.root);
    }
    
/*
Function: printTree
Author: Nicholas Johnson
Description: Prints the data structure to the screen
Inputs: AVLNode t is passed in as a parameter
Outputs: Output the Binary Tree to the screen
*/        
    
    public void printTree(AVLnode t)
    {
        if(t != null)
        {
            printTree(t.Aleft);
            System.out.println(t.element);
            printTree(t.Aright);
        }
    }
    
/*
Function: height
Author: Nicholas Johnson
Description: Measures the height of the tree
Inputs: Avlnode t is passed in as a parameter
Outputs: Returns the height of the tree
*/     
    
    private int height(AVLnode<T> t)
    {
        return t == null ? -1 : t.height;
    }
    
/*
Function: remove
Author: Nicholas Johnson
Description: Removes data from AvlTree
Inputs: T x is passed in as a paramter
Outputs: Sends T x and the data section root to other remove method
*/    
    
    public void remove(T x)
    {
        remove(x, this.root);
    }
    
/*
Function: remove
Author: Nicholas Johnson
Description: Removes data from the data structure
Inputs: T x and AVLnode root are passed in as a parameter
Outputs: Removes data from the AVL Tree
*/  
    
    private void remove(T x, AVLnode <T> root)
    {
        if (root == null)
            return;
        else if(x.compareTo(root.element) < 0)
        {
            remove(x, root.Aleft);
        
        if(height(root.Aright.Aright) >= height(root.Aright.Aleft))
            rotateWithRightChild(root);
        else
            doubleWithRightChild(root);
        }
        else if(x.compareTo(root.element) > 0)
        {
            remove(x, root.Aright);
            if(height(root.Aleft) - height(root.Aright) > 1)
            {
                if(height(root.Aleft.Aleft) >= height(root.Aleft.Aright))
                    rotateWithLeftChild(root);
                else
                   doubleWithLeftChild(root);
            }
            
        }
        else if(root.Aleft == null || root.Aright == null)
        {
            AVLnode<T> temp = root.Aleft != null ? root.Aleft : root.Aright;
            
            if(temp == null)
            {
                temp = root;
                root = null;
            }
            else
            {
                root = temp;
            }
            temp = null;
        }
        else
        {
            AVLnode temp = findMin(root.Aright);
            root.element = (T) temp.element;
            remove((T) temp.element, root.Aright);
        }
        if(root != null)
        {
            root.height = Math.max(height(root.Aleft), height(root.Aright)) + 1;
        }
    }
    
/*
Function: findMax
Author: Nicholas Johnson
Description: Finds the max data from the data structure
Inputs: No inputs
Outputs: Sends data section root to the other find max method
*/        
    
    public T findMax()
    {
        return (T) elementAt(findMax(this.root));
    }
    
/*
Function: findMax
Author: Nicholas Johnson
Description: Find the max data from the data structure
Inputs: AVLnode t is passed in as a parameter
Outputs:n Returns the max value from the AVLtree
*/        
    
    private AVLnode findMax(AVLnode t)
    {
        if(t== null)
            return t;
        while(t.Aright != null)
            t = t.Aright;
        return t;
    }
    
/*
Function: find
Author: Nicholas Johnson
Description: Finds a specific piece of data from the AVLtree
Inputs: T x is passed in as a parameter
Outputs: Sends T x and the data section root to the other find method
*/        
    
    public T find(T x)
    {
        return (T) elementAt(find(x, this.root));
    }
    
/*
Function: find
Author: Nicholas Johnson
Description: Finds a specific piece of data from the data structure
Inputs: T x and AVLnode t are passed in as parameters
Outputs: Returns the data that was found
*/        
    
    private AVLnode find(T x, AVLnode <T> t)
    {
        while(t != null)
            if(x.compareTo(t.element) < 0)
                t = t.Aleft;
            else if(x.compareTo(t.element) > 0)
                t = t.Aright;
            else
                return t;
        return null;
    }
    
/*
Function: makeEmpty
Author: Nicholas Johnson
Description: Makes the data struture empty
Inputs: No inputs
Outputs: Sends data section root to the other makeEmpty method
*/        
    
    public void makeEmpty()
    {
        makeEmpty(root);
    }

/*
Function: makeEmpty
Author: Nicholas Johnson
Description: Makes the data structure empty
Inputs: AVlnode t is passed as a parameter
Outputs: Sets everything to null
*/        
    
    private void makeEmpty(AVLnode t)
    {
        if(t != null)
        {
            makeEmpty(t.Aleft);
            makeEmpty(t.Aright);
            t = null;
        }
        t = null;
    }
    
/*
Function: isEmpty
Author: Nicholas Johnson
Description: Returns an empty data section
Inputs: no inputs
Outputs: Returns an empty data section
*/        
   
    
    public boolean isEmpty()
    {
        return root == null;
    }
    
/*
Function: findMin
Author: Nicholas Johnson
Description: Finds the min data from the data structure
Inputs: No inputs
Outputs: When called sends data section root to other findMin method
*/      
    
    public T findMin()
    {
        return (T) elementAt(findMin(this.root));
    }
    
/*
Function: findMin
Author: Nicholas Johnson
Description: Find the min data from the data structure
Inputs: AVLnode t is passed in as a parameter
Outputs: Returns the min data from the left side of the AVLTree.
*/        
    
    private AVLnode findMin(AVLnode t)
    {
        if(t == null)
            return t;

        while(t.Aleft != null)
            t = t.Aleft;
        return t;
    }
    
/*
Function: elementAt
Author: Nicholas Johnson
Description: Sets the element variable
Inputs: AVLnode t is passed as a parameter
Outputs: Sets the AVLnode data section element to t
*/        
    public T elementAt(AVLnode<T> t)
    {
        if(t == null)
            return ITEM_NOT_FOUND;
        else
            return (T) t.element;
    }
    
/*
Function: rotateWithLeftChild
Author: Nicholas Johnson
Description: Balances the data structure
Inputs: AVLnode k2 is passed as a paramter
Outputs: Balances the left side of tree through roatations/ references from one
node to another.
*/        
    
    private void rotateWithLeftChild(AVLnode<T> k2)
    {
        AVLnode k1 = k2.Aleft;
        k2.Aleft = k1.Aright;
        k1.Aright = k2;
        k2.height = Math.max(height(k2.Aleft), height(k2.Aright)) + 1;
        k1.height = Math.max(height(k1.Aleft), k2.height) + 1;
        k2 = k1;
    }
    
/*
Function: rotateWithRightChild
Author: Nicholas Johnson
Description: Balances the data structure
Inputs: AVLnode k1 is passed as a paramter
Outputs: Balances the right side of AVLtree through roatations/ references from one
node to another.
*/        
    
    private void rotateWithRightChild(AVLnode<T> k1)
    {
        AVLnode k2 = k1.Aright;
        k1.Aright = k2.Aleft;
        k2.Aleft = k1;
        k1.height = Math.max(height(k1.Aleft), height(k1.Aright)) + 1;
        k2.height = Math.max(height(k2.Aright), k1.height) + 1;
        k1 = k2;
    }
    
/*
Function: doubleWithLeftChild
Author: Nicholas Johnson
Description: Does a double rotation to balance the AVLtree
Inputs: AVLnode k3 is passed as a parameter
Outputs: Balances the left side of the AVLtree
*/        
    
    private void doubleWithLeftChild(AVLnode k3)
    {
        rotateWithRightChild(k3.Aleft);
        rotateWithLeftChild(k3);
    }
    
/*
Function: doubleWithRightChild
Author: Nicholas Johnson
Description: Does a double rotation to balance the AVLtree
Inputs: AVLnode k1 is passed as a parameter
Outputs: Balances the right side of the AVLtree
*/              
    
    private void doubleWithRightChild(AVLnode k1)
    {
        rotateWithLeftChild(k1.Aright);
        rotateWithRightChild(k1);
    }
    

}
