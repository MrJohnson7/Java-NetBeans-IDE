/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class is extended from Comparable and can be used to build a binary
tree data structure. This class is able to compare what data is smaller and able
to place the data in appropriate positon.
*/
package project5trees;


public class BinaryTree <T extends Comparable<T>>
{
    
/*
Function: Data section
Author: Nicholas Johnson
Description: Node called root set to null
Inputs: Holds data that is passed to it
Outputs: Holds the data from the class
*/        
   
    public Node<T> root = null;
    
/*
Function: insert
Author: Nicholas Johnson
Description: Inserts a node
Inputs: T data is passed as a parameter
Outputs: Sends T data and the data section root to other insert method
*/        
    
    public void insert(T data)
    {
        if(this.root == null)
        {
            root = new Node(data);
        }
        else
        {
            this.insert(data, this.root);
        }
    }
    
/*
Function: insert
Author: Nicholas Johnson
Description: Inserts a node into the binary tree
Inputs: T data and Node n are passed as parameters
Outputs: Node is placed in to data structure
*/        
    
    private void insert(T data, Node<T> n)
    {
      
        if(data.compareTo(n.Data) < 0)
        {
            if(n.left == null)
                n.left = new Node(data);
            else
                insert(data, n.left);
        }
        else
        {
            if(n.right == null)
                n.right = new Node(data);
            else
                insert(data, n.right);
        }
    
        return;
    }
    
/*
Function: remove
Author: Nicholas Johnson
Description: Removes data from BinaryTree
Inputs: T data is passed in as a paramter
Outputs: Sends T data and the data section root to other remove method
*/        
    
    public void remove(T data)
    {
       this.remove(data, this.root);
    }
    
/*
Function: remove
Author: Nicholas Johnson
Description: Removes data from the data structure
Inputs: T data and Node n are passed in as a parameter
Outputs: Removes data from the Binary Tree
*/        
    private Node remove(T data, Node<T> n)
    {
        if(this.root == null)
        {
            return n;
        }
        else if(data.compareTo(n.Data) < 0)
        {
            n.left = this.remove(data, n.left);
        }
        else if(data.compareTo(n.Data) > 0)
        {
            n.right = this.remove(data, n.right);
        }
        
        else if(n.left != null && n.right != null)
        {
            n.Data = (T) findMin(n.right);
            remove(n.Data, n.right);
        }
        else
        {
            n = (n.left != null) ? n.left : n.right;
        }
        
        return n;
    }
    
/*
Function: contains
Author: Nicholas Johnson
Description: Looks for specific data in the data structure
Inputs: T data is passed in as a parameter
Outputs: Sends T data and data section root to other contains method
*/        
    
    public boolean contains(T data)
    {
        return this.contains(data, this.root);
    }
    
/*
Function: contains
Author: Nicholas Johnson
Description: Finds specific data in the data structure
Inputs: T data and Node n are passed in as parameters
Outputs: Returns a boolean true if specific data is found
*/        
    
    private boolean contains(T data, Node<T> n)
    {
        if(n == null)
            return false;
        else if(data.compareTo(n.Data) < 0)
            return contains(data, n.left);
        else if(data.compareTo(n.Data) > 0)
            return contains(data, n.right);
        else
            return true;
        
    }
    
/*
Function: findMin
Author: Nicholas Johnson
Description: Finds the min data from the data structure
Inputs: No inputs
Outputs: When called sends data section root to other findMin method
*/        
    
    public T findMin()
    {
        return this.findMin(this.root);
    }
    
/*
Function: findMin
Author: Nicholas Johnson
Description: Find the min data from the data structure
Inputs: Node n is passed in as a parameter
Outputs: Returns the min data from the left side of the Binary Tree.
*/        
    
    public T findMin(Node<T> n)
    {
        if(n.left == null)
        {
            return n.Data;
        }
        else
        {
            return (T) findMin(n.left);
        }
    }
    
/*
Function: findMax
Author: Nicholas Johnson
Description: Finds max value from the data structure
Inputs: No inputs
Outputs: Sends data section root to other findMax method
*/        
    
    public T findMax()
    {
        return this.findMax(this.root);
    }
    
/*
Function: findMax
Author: Nicholas Johnson
Description: Finds max value from the data section
Inputs: Node n is passed in as a parameter
Outputs: Returns the max data from the right side of the Binary Tree
*/        
    
    private T findMax(Node<T> n)
    {
        if(n.right == null)
            return n.Data;
        else
            return (T) findMax(n.right);
    }
    
/*
Function: isEmpty
Author: Nicholas Johnson
Description: See if data struture is empty
Inputs: No inputs
Outputs: Return data section root as empty / null
*/        
    
    public boolean isEmpty()
    {
        return this.root == null;
    }
    
/*
Function: printTree
Author: Nicholas Johnson
Description: Prints the data structure
Inputs:No inputs
Outputs: Sends the data section root to other printTree method
*/        
        
    
    public void printTree()
    {
        this.printTree(this.root);
    }
    
/*
Function: printTree
Author: Nicholas Johnson
Description: Prints the data structure to the screen
Inputs: Node n is passed in as a parameter
Outputs: Output the Binary Tree to the screen
*/        
    
    private void printTree(Node n)
    {
        if(n != null)
        {
            System.out.println(n.Data);
            printTree(n.left);
            printTree(n.right);
        }
     
    }
    
}
