/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: AVLnode class. Generic class/ Comparable. This class has a public default constructor
as well as public data section. This is so the other classes in the program can access
the data section of this class. The data section here stores the node pairs and 
makes it easy to search through a node. ALso has variable Element, Data, and height
 */


package project5trees;


public class AVLnode <T extends Comparable<T>>
{

/*
Function: Data Section
Author: Nicholas Johnson
Description: Nodes, T type variables, int variable
Inputs: No inputs
Outputs: Holds data for the class
*/          
    
    
    public T Data;
    public AVLnode Aleft;
    public AVLnode Aright;
    public T element;
    public int height;
    
/*
Function: AVLnode
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs, made public
Outputs: Allows other classes to use the data section
*/    
    
    public AVLnode()
    {
        
    }
    
/*
Function: AVLnode
Author: Nicholas Johnson
Description: Working Constructor
Inputs: T data
Outputs: Sets the data section to T data
*/          
    
    public AVLnode(T data)
    {
        this.Data = data;
    }
    
/*
Function: AVLnode
Author: Nicholas Johnson
Description: Sets the data section
Inputs: T data, AVLnode r, and AVLnode l are passed as parameters
Outputs: Sets the data section to the parameters being passed in
*/          
    
    public AVLnode(T data, AVLnode<T> r, AVLnode<T> l)
    {
        this.Aleft = l;
        this.Aright = r;
        this.element = data;
    }
    
/*
Function: AVLnode
Author: Nicholas Johnson
Description: Sets the data section
Inputs: T data, AVLnode r, AVLnode l, amd in h are passed as parameters
Outputs: Sets the data section to the parameters being passed in
*/      
    
    public AVLnode(T data, AVLnode<T> r, AVLnode<T> l, int h)
    {
        this.Aleft = l;
        this.Aright = r;
        this.element = data;
        this.height = h;
    }
}
