/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program works with Binary and AVL trees. This program allows the
user to add/ delete/find from trees. This program also reads from a file and counts
the words in a file and how many times they are printed in the txt file.
*/
package project5trees;


public class Project5Trees 
{

    
    public static void main(String[] args) 
    {
       
       WordCount testing = new WordCount();
       testing.readFile();
    }
    
}
