/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: WordCount class uses the binary tree to read a file and insert all the
words onto a binary tree. This class seperates all the words excluding any punctuation
marks, and counts how many times a word is read.
*/

package project5trees;

import java.io.BufferedReader;
import java.io.FileReader;


public class WordCount extends BinaryTree
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Node nCount
Inputs: No inputs
Outputs: Holds data for the class
*/    
    
    private Node Ncount = new Node();
    
/*
Function: readFile
Author: Nicholas Johnson
Description: Reads the file WordCountTest.Txt
Inputs: No inputs
Outputs: When called this method seperates all the words from the txt file
and is suppose to keep track of how many times a word is in  the file. If the word is found more 
than once in the file then that word will not be added to the tree but the occurence variable
willl be incremented by one. Also outputs a total word count and word count.
*/         
    
    public void readFile()
    {
        FileReader fr = null;
        BufferedReader br = null;
        String line;
        String reference;
        int count = 0;
        Node Ncount = new Node();
        int count2 = 0;
        

        try
        {
            fr = new FileReader("WordCountTest.txt");
            br = new BufferedReader(fr);
            
            while((line = br.readLine()) != null)
            {
                char[] chars = line.toCharArray();
                String replaceLine = "";
                
                for(int i = 0; i < chars.length; i++)
                {
                     
                    
                    if(chars[i] != ' ')
                    {
                        replaceLine = replaceLine + chars[i];
                        replaceLine = replaceLine.replaceAll("[^a-zA-Z]", "");
                        replaceLine = replaceLine.concat(": 1");
                    }
                   
                    else
                    {   
                        
                        if(this.contains(replaceLine))
                        {
                        reference = replaceLine;
                        count2++;
                        Ncount.occurence++;
                        this.remove(reference);
                        replaceLine = replaceLine.replaceAll("[^a-zA-Z]", "");
                        String num = Integer.toString(Ncount.occurence);
                        this.insert(replaceLine + ": " + num);
                        replaceLine = "";
                        count++;
                        Ncount.occurence = 0;
                        }
                        else
                        {
                        count2++;
                        this.insert(replaceLine);
                        replaceLine = "";
                        }
                       
                    }
                  
                }
            }
            
            this.printTree();
            
            System.out.println("Total Word Count: ");
            System.out.println(count2);
            System.out.println("Word Count: ");
            System.out.println(count);
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        finally
        {
            try
            {
                br.close();
                fr.close();
            }
            
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
           
        }
    }
    
}
 