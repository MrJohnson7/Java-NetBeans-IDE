/* Nicholas Johnson
 * 10/20/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Node class. Generic class. This class has a public default constructor
as well as public data section. This is so the other classes in the program can access
the data section of this class. The data section here stores the node pairs and 
makes it easy to search through a node.
 */
package project5trees;


public class Node <T extends Comparable<T>>
{
    
/*
Function: Data section
Author: Nicholas Johnson
Description: five variables. Nodes and Generic type
Inputs: Holds data
Outputs: left/right will hold Node data, Data will hold generic type data, Occurence 
and wordCount both hold int values. 
*/       
    
    public T Data;
    public Node left;
    public Node right;
    public int occurence = 1;
    public int wordCount;
    
/*
Function: Node
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs, made public
Outputs: Allows other classes to use the data section
*/    
    
  
    public Node()
    {
        
    }
    
/*
Function: Node
Author: Nicholas Johnson
Description: Working Constructor
Inputs: T data
Outputs: Sets the data section to T data
*/     
    
    public Node(T data)
    {
        this.Data = data;
    }
   
}

