/* Nicholas Johnson
 * 12/1/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program creates a graph of cities, by hashing the initial city
and using the initial city as a key for other cities to be put into the graph. This
program also traverses the list and outputs the cities that were visited only once.
*/
package project8graphs;


public class Project8Graphs 
{
    
    public static void main(String[] args) 
    {
        Graph test = new Graph();
        System.out.println("Cities Graph: ");
        test.hash("Canyon Lake");
        test.hash("Sun City");
        test.hash("Lake Elsinore");
        test.hash("Murrieta");
        test.hash("Menifee");
        test.hash("Temecula");
        test.addEdge("Canyon Lake", "Sun City");
        test.addEdge("Canyon Lake", "Lake Elsinore");
        test.addEdge("Sun City", "Canyon Lake");
        test.addEdge("Sun City", "Menifee");
        test.addEdge("Lake Elsinore", "Canyon Lake");
        test.addEdge("Lake Elsinore", "Murrieta");
        test.addEdge("Murrieta", "Lake Elsinore");
        test.addEdge("Murrieta", "Temecula");
        test.addEdge("Murrieta", "Menifee");
        test.addEdge("Menifee", "Sun City");
        test.addEdge("Menifee", "Murrieta");
        test.addEdge("Menifee", "Temecula");
        test.addEdge("Temecula", "Murietta");
        test.addEdge("Temecula", "Menifee");
        
        test.printGraph();
        System.out.println("\n" + "Cities Visited: " + "\n");
        test.depthFirstTraversal();
        test.printCities();
    }
    
}
