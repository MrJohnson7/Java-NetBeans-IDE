/* Nicholas Johnson
 * 12/1/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class reads data from a file and loads the data read to hash table.
*/
package project8graphs;

import java.util.ArrayList;


public class Graph <T>
{
    
/*
Function: Data section
Author: Nicholas Johnson
Description: A couple ArrayList of linked lists
Inputs: No inputs
Outputs: Stores data in these ArrayLists, used to create a graph.
*/    
    private ArrayList<LinkedList<T>> table;
    private ArrayList<LinkedList<T>> citiesVisited = new ArrayList<LinkedList<T>>(5);
    private int count = 0;
    
/*
Function: Graph
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs
Outputs: Sets the table size to 6.
*/    
    public Graph()
    {
        this.table = new ArrayList<LinkedList<T>>(6);
    }
    
/*
Function: Graph
Author: Nicholas Johnson
Description: Overloaded constructor
Inputs: Int variable called tableSize
Outputs: Sets the table size to the variable tableSize
*/    
    public Graph(int tableSize)
    {
        this.table = new ArrayList<LinkedList<T>>(tableSize);
    }  
    
/*
Function: hash
Author: Nicholas Johnson
Description: This method creates a hash table for the file HashData file. When a
String gets sent to this method it takes the hash val of only the charcters in the
String by modulous 53. If the table size is 0 then it adds a linked list into
that table position. It adds a node of the key and hashVal to the linked list.
If two Strings have the same hash val then we add another node to that linked list
with the same hash val. If there isnt any identical hash val then we add another linkedlist
to the next open space in the array list.
Inputs: String parameter called key.
Outputs: This String is sent to the arraylist of linkedlists.
*/
    
    public void hash(String key)
    {
      
       String seperateChars = key.replaceAll("[^a-zA-Z]", "");
       double hashVal = (sumAscii(seperateChars) % (53));
      
        if(table.size() == 0)
            {
             LinkedList list = new LinkedList();
             list.Head = new Node(key, hashVal);
             table.add(list);
             return;
            }
        else
        {
            for (int i = 0; i <= table.size()-1;i++)
            {
                if(table.get(i).Head.Reference == hashVal)
                {
                    Node temp = new Node(key,hashVal);
                    table.get(i).addNode((T)temp.Data);
                    return;
                }
            }
            LinkedList elseList = new LinkedList();
            elseList.Head = new Node(key, hashVal);
            table.add(elseList);               
        }
    }
    
/*
Function: sumAscii
Author: Nicholas Johnson
Description: Turns Strings into their int ascii value.
Inputs: String parameter called s
Outputs: Returns the ascii value of the String
*/    
    
    public int sumAscii(String s)
    {
        int sum = 0;
        for(int i = 0; i <s.length(); i++)
        {
            sum += (int) (s.charAt(i));
        }
         return sum;
    }  
    
/*
Function: printGraph
Author: Nicholas Johnson
Description: This method prints the table with the use of the printList method
in our linked list class.    
Inputs: No inputs.
Outputs: Prints the hash table to the screen
*/
    
    public void printGraph()
    {
        for(int i = 0; i < table.size(); i++)
        {
            table.get(i).printList();
            System.out.println("|| (end of list)" + "\n");
        }
        System.out.println("End Of Graph");
    } 
    
/*
Function: addEdge
Author: Nicholas Johnson
Description: This method adds data to the graph    
Inputs: Two Strings called src, and dest
Outputs: Adds data to the graph by first searching for the String src AKA key 
when this "key" is found the String dest is added to that linked list.
*/    
    
    
    public void addEdge(String src, String dest)
    {
        String nodeRename;
        String seperateChars;
        String srcSeperateChars = src.replaceAll("[^a-zA-Z]", "");
        
        for(int i = 0; i < this.table.size(); i++)
        {
            Node p = table.get(i).Head;
            nodeRename = p.Data.toString();
            seperateChars = nodeRename.replaceAll("[^a-zA-Z]", "");
            
            if(seperateChars.equals(srcSeperateChars))
            {
                Node temp = new Node(dest);
                table.get(i).addNode((T)temp.Data);
                return;
            }
            
        }
        
    }
    
/*
Function: depthFirstTraversal
Author: Nicholas Johnson
Description: This method traverses through the arrayList of cities and only adds
the city once to another arrayList.
Inputs: No inputs.
Outputs: Creates another arrayList that only includes each city visited once.
*/
    
    public void depthFirstTraversal()
    {
        String rename;
        
        for(int i = 0; i < this.table.size(); i++)
        {
           
            Node p = table.get(i).Head;
            
            while(p != null)
            {
                rename = p.Data.toString();
                
                if(citiesVisited.isEmpty())
                {
                   
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                   
                }
                else
                {
                    if(p.Data != citiesVisited.get(0).Head.Data && this.count == 1)
                    {
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                    }
                }
                if(p.Data != citiesVisited.get(0).Head.Data && 
                        p.Data != citiesVisited.get(1).Head.Data && this.count == 2)
                {
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                }
                else
                {
                    if(p.Data != citiesVisited.get(0).Head.Data && 
                            p.Data != citiesVisited.get(1).Head.Data &&
                            p.Data != citiesVisited.get(2).Head.Data && this.count == 3)
                    {
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                    }
                    
                }
                if(p.Data != citiesVisited.get(0).Head.Data && 
                        p.Data != citiesVisited.get(1).Head.Data && 
                        p.Data != citiesVisited.get(2).Head.Data &&
                        p.Data != citiesVisited.get(3).Head.Data && this.count == 4)
                {
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                }
                else
                {
                    if(p.Data != citiesVisited.get(0).Head.Data && 
                            p.Data != citiesVisited.get(1).Head.Data &&
                            p.Data != citiesVisited.get(2).Head.Data &&
                            p.Data != citiesVisited.get(3).Head.Data && 
                            p.Data != citiesVisited.get(4).Head.Data &&this.count == 5)
                    {
                    LinkedList list = new LinkedList();
                    list.Head = new Node(rename);
                    citiesVisited.add(list);
                    this.count++;
                    }
                    
                }
                p = p.Next;
            }
        }
    }
    
/*
Function: printCities
Author: Nicholas Johnson
Description: This method prints the cities with the use of the printList method
in our linked list class.    
Inputs: No inputs.
Outputs: Prints arrayList of cities to the screen
*/    
    
    public void printCities()
    {
        for(int i = 0; i < citiesVisited.size(); i++)
        {
            citiesVisited.get(i).printList();
            System.out.println("|| (end of list)" + "\n");
        }
        
    }
}
