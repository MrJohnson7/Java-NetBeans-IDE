/* Nicholas Johnson
 * 8/25/2018
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: BigDecimalException class. This class is derived from CharExcpetion and
uses inheritance to call the constructors of the CharException class. This class also
throws error message when the complier encounters an error, when input is not a 
valid character.
 */

package project1.object.creation;

    /*
    Function: Class: BigDecimalException
    Author: Nicholas Johnson
    Description: This class is derived from CharException, also uses inheritance
    - CharException being the mother class
    Inputs: This class extends CharException, this class inherits all of CharException class
    - methods
    Outputs: This outputs an error message, when a digit or a decimal have been comiled
    */

public class BigDecimalException extends CharException
{
    /*
    Function: Default constructor BigDecimalException 
    Author: Nicholas Johnson
    Description: This class is calling the CharExcpetion class with the keyword "super"
    Inputs: Calls the mother class constuctor to put out error message
    Outputs: Outputs an error message when a digit or a decimal point have been compiled
    */
    
    public BigDecimalException()
    {
      super();
        
    }
    
    /*
    Function: Working constructor: BigDecimalException
    Author: Nicholas Johnson
    Description: Calls the mother class to output the error message
    Inputs: Parameter of data type String called error
    Outputs: Calls the mother class and passes the string error to be displayed
    */
    
    public BigDecimalException(String error)
    {
        super(error);
    }
    
    
}
