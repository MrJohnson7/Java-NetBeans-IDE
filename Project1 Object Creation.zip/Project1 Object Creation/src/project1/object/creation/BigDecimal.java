/* Nicholas Johnson
 * 8/25/2018
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: BigDecimal class. The data section for this class is an arraylist 
of complex type Chars which then can be casted to numbers, so we can make a huge big
decimal. We want to make a big decimal so big that a primitive type double cannot hold
this decimal due to short memeory. This class also has functionality to read through a specific 
file named "numbers.text" line by line. Using BigDecimal objects we get each  line 
from the file and save these numbers into a new arraylist of BigDecimal. Then sending this new arraylisgt to
the writeFile() method where we seperate the whole and fractional parts of the number
and write each into two seperate files called wholeNumbers.txt and fractonNumbers.txt.
 */


package project1.object.creation;

/*
Function: Imports. otherwise program will show errors
Author: Nicholas Johnson
Description: File IO, and arraylist
Inputs: Imports
Outputs: Program runs
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;


/*
Function: BigDecimal class
Author: Nicholas Johnson
Description: BigDecimal to hold a huge decimal number
Inputs: Chars, doubles, ints, strings
Outputs: Decimals, files, Strings , ints, doubles
*/


public class BigDecimal 
{
    /*
    Function: ArrayList: digits
    Author: Nicholas Johnson
    Description: ArrayList holds complex types Char 
    Inputs: Chars "complex type"
    Outputs: Big Decimal, ArrayList, arraylist of numbers 
    */
   
    private ArrayList<Char> digits = new ArrayList<Char>();
    
    
    /*
    Function: Default Constructor: BigDecimal
    Author: Nicholas Johnson
    Description: Sets the data section 
    Inputs: Three default numbers '0' '.' '0'
    Outputs: Sets arraylist to the default numbers
    */
    
    public BigDecimal()
    {
        digits.add(new Char('0'));
        digits.add(new Char('.'));
        digits.add(new Char('0'));
   
    }
    
    /*
    Function: Working constructor: BigDecimal
    Author: Nicholas Johnson
    Description: Sets the data section, also checks to see if there is an
    - actual digit, and making sure it dosnt equal '.', also turning the string into a int
    Inputs: Parameter being passed is a string
    Outputs: Sets the data section. if not a digit an exception message will pop 
    - up informing user of  no digit.
    */
    
    public BigDecimal(String value) throws BigDecimalException
    {
      int newDigit = Integer.parseInt(value);
      Char nDigit = new Char();
     
      if(newDigit >= 0 && newDigit != '.' )
      {
      nDigit.add((char) newDigit);
      digits.add(nDigit);
      }
      else
      {
          throw new BigDecimalException();
          
      }
        
    }
    
    /*
    Function: Mutator method: equals
    Author: Nicholas Johnson
    Description: Sets the data section to the primitive argument also checks to
    - see if the char passed is a digit, to be passed into arraylist.
    Inputs: primitive char parameter called ch.
    Outputs: If the parameter being passed is a digit, it will be added to the array list
    - if not a digit an exception message will pop up informing user of  no digit.
    */
    
    public void equals(char ch) throws BigDecimalException
    {
       if(Character.isDigit(ch))
       {
            
         int charDigit = (int) ch;
         Char nDigit = new Char();
         nDigit.add((char) charDigit);
         digits.add(nDigit);
       
       }
       else
       {
           throw new BigDecimalException();
       }
     
    }
    
    /*
    Function: Mutator Method: equals
    Author: Nicholas Johnson
    Description: Method makes sure the parmeter being passed contains a number and
    - dosn't equal "."
    Inputs: String parameter is being passed in called value.
    Outputs: If the parameter being passed is a digit, it will be added to the array list
    - if not a digit a exception message will pop up informing user of  no digit.
    */
    
    public void equals(String value) throws BigDecimalException
    {
      int newDigit = Integer.parseInt(value);
      Char nDigit = new Char();
      
      if(newDigit >= 0 && newDigit != '.' )
      {
      nDigit.add((char) newDigit);
      digits.add(nDigit);
      }
      else
      {
          throw new BigDecimalException();
      }
    
   
    }
    
    
    /*
    Function: Method: add
    Author: Nicholas Johnson
    Description: Adds the values together and returns the result as a BigDecimal
    Inputs: Complex types parameter being passed of BigDecimal called one and two
    Outputs: These two parameters will be added to each other;
    */
    
    public BigDecimal add(BigDecimal num)
    {
        return null; 
         
    }
    
    
    /*
    Function: Method: sub
    Author: Nicholas Johnson
    Description: Subtracts the values and returns the result as a BigDecimal
    Inputs: Complex types parameter being passed of BigDecimal called one and two
    Outputs: These two parameters will be added to each other;
    */
    
    public BigDecimal sub(BigDecimal num)
    {
        return null;
        
    }
    
    /*
    Function: Method: toString
    Author: Nicholas Johnson
    Description: This method gets one complex type Char from the arraylist and is put into
    - a new Char class and casted into a primitive char, chars are then put into the String
    - and method returns a String.
    Inputs: For loop through the arraylist
    Outputs: returns the arraylist as a String.
    */
    
    public String toString()
    {
        String num = " ";
        for(int i = 0; i <= digits.size(); i++)
        {
            Char ch = digits.get(i);
            num += ch.toChar();
        }
        return num;
    }
    
    /*
    Function: Method: toDouble
    Author: Nicholas Johnson
    Description: Returns the value stored in the arraylist as a double
    Inputs: calls the toString method to get arraylist into a string
    Outputs: this string will then be casted into a double. 
    */
    
    public double toDouble()
    {
      return Double.valueOf(this.toString());
      
    }
    
    
    /*
    Function: Method: at
    Author: Nicholas Johnson
    Description: Return the value at the index specified as a Char
    Inputs: Parameter of primitive type int
    Outputs: gets the exact index of the arraylist and returns as a Char
    */
    
    public Char at(int index)
    {
        return digits.get(index);
    }
    
    /*
    Function: Method: wholeNumber
    Author: Nicholas Johnson
    Description: Returns only the whole number portion of the decimal number as an int
    Inputs: Loops through the arraylist looking for the decimal point
    Outputs: Only takes the number before the decimal point, which is then casted to an int
    */
    
    public int wholeNumber()
    {
        
        String wholeNum = "";
        for(int i = 0; i <= digits.indexOf(new Char('.')); i++)
        {
            wholeNum += digits.get(i).toString();
        }
        
        
        return Integer.parseInt(wholeNum);
    }
    
    /*
    Function: Method: fraction
    Author: Nicholas Johnson
    Description: Return the fractional portion of the number as a double
    Inputs: Loops through the arraylist looking for the decimal point, so the loop
    - will start when it locates the decimal point
    Outputs: Only takes the number after the decimal point, including the decimal point,
    - which is then casted and returned as a double
    */
    
    public double fraction()
    {
        
        String fracNum = "";
        for(int i = digits.indexOf(new Char('.')) ; i <= digits.size(); i++)
        {
            fracNum += digits.get(i).toString();
        }
        
        return Double.parseDouble(fracNum);
    }
    
    /*
    Function: Method: readFile
    Author: Nicholas Johnson
    Description: Reads a file, saves each line into an array list, close the file after 
    - reading with the Try, Catch, Finally block. return type is an Arraylist
    Inputs: No parameters being passed, method reads numbers.txt
    Outputs: Return the arraylist with all the lines from numbers.txt
    */
    
    public ArrayList<BigDecimal> readFile()
    {
        FileReader fr = null;
        BufferedReader br = null;
        ArrayList <BigDecimal> newArrayList = new ArrayList<BigDecimal>();
        
        try
        {
            fr = new FileReader("Numbers.txt");
            br = new BufferedReader(fr);
            String line;
            while((line = br.readLine()) != null)
            {
                
               BigDecimal inputOutput  = new BigDecimal(line);
               newArrayList.add(inputOutput);
         
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        finally
        {
            try
            {
                br.close();
                fr.close();
                        
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
           
        }
        return newArrayList;
        
        
    }
    
    /*
    Function: Method: writeFile
    Author: Nicholas Johnson
    Description: Writes two seperate files using the arraylist returned from readFile method
    Inputs: The parameter arraylist called seperateList which is from numbers.txt
    Outputs: Seperates the numbers into integers and doubles and placed into two
    - seperate files 
    */
    
    public void writeFile(ArrayList<BigDecimal> seperateList)
    {
     
        
        PrintWriter wholeNumbers = null;
        FileWriter writeWholeNumbers = null;
        
        PrintWriter fractionNumbers = null;
        FileWriter writeFractionNumbers = null;
        
        try
        {
            writeWholeNumbers = new FileWriter("wholeNumbers.txt");
            wholeNumbers = new PrintWriter(writeWholeNumbers);
            
            writeFractionNumbers = new FileWriter("fractionNumber.txt");
            fractionNumbers = new PrintWriter(writeFractionNumbers);
            
            for(int i = 0; i <= seperateList.size(); i++)
            {
                int returnNum = seperateList.get(i).wholeNumber();
                double returnFracNum = seperateList.get(i).fraction();
               
                wholeNumbers.write(returnNum);
                fractionNumbers.write(Double.toString(returnFracNum));
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
            
        }
        finally
        {
            try
            {
                wholeNumbers.close();
                writeWholeNumbers.close();
                fractionNumbers.close();
                writeFractionNumbers.close();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
        }
        
    }
    
    
}
