/* Nicholas Johnson
 * 8/25/2018
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: CharException class. This class throws an error message when an invalid character
has been entered. This is also the mother class for the BigDecimalException class.
only two constructors meant for throwing an error message;
*/

package project1.object.creation;

    /*
    Function: CharException Class that extends Exception
    Author: Nicholas Johnson
    Description: This class throws a Exception when an invalid put has been compiled
    Inputs: Trying to see if the code works
    Outputs: Throws an error message
    */
    

public class CharException extends Exception
{
    /*
    Function: Default Constructor: CharException
    Author: Nicholas Johnson
    Description: Protected so the BigDecimalException class can call these constructors
    - sets error message
    Inputs: Constructor includes an error message
    Outputs: Outputs the erroe message "Invalid Character"
    */
    
    protected CharException()
    {
        this("Invalid Character");
    }
    
    /*
    Function: Working Constructor: CharException
    Author: Nicholas Johnson
    Description: Protected so the BigDecimalException class can call these constructors
    - sets error message
    Inputs: Parameter that is data type String called error
    Outputs: Super: invoke or call the default constructor/ parent class and sets of error message.
    */
    
    protected CharException(String error)
    {
        super(error);
    }
    
}
