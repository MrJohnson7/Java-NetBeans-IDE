/* Nicholas Johnson
 * 8/25/2018
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program Project1ObjectCreation creates many complex types, such as
Char and BigDecimal. The Char class has a primitive data type char, which makes it able to work
on primitive chars. This program uses these two complex types to come up with an 
arraylist of Char as well. In order for the program to work input does have limitations.
If the program is looking for chars then we need to put in a char input or an primitive 
type int inbetween the number range of 32 - 127 because these numbers can be casted 
to a char. Since BigDecimal is an also an arraylist of complex type Char we need
to be able to send input that can be casted to a primitive type char since that is what
the Char class is, a char. These chars need to be casted into an int/ double so we can actually create
a big decimal in our big decimal class. The user input can also be returned as a string or double
from casting a char to a string which then can be casted to a double.

 */
package project1.object.creation;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Project1ObjectCreation extends CharException
{

    
    public static void main(String[] args) 
    {
       Char ch = new Char('A');
       Char c = new Char('B');
       
       System.out.println(ch.add(c));
       System.out.println(ch.toChar() + " In Hex: " + ch.toHexString());
       System.out.println(ch.toChar() + " In Decimal: " + ch.toInt());
       System.out.println("As a String: " + c.toString());
       
       
       try
       {
           System.out.println(ch.toChar());
           System.out.println("Try to set 140 as charcter");
           c.equals(140);
           
       }
       catch(CharException ce)
       {
           System.out.println(ce.getMessage());
       }
    
       
       BigDecimal bd = new BigDecimal();
       System.out.println("Default Constructor for BigDeciaml: ");
       System.out.println(bd.at(0));
       System.out.println(bd.at(1));
       System.out.println(bd.at(2));
       
       
       BigDecimal returnBigDecimal = new BigDecimal();
       BigDecimal writeToFile = new BigDecimal();
       ArrayList <BigDecimal> returnArrayList = new ArrayList<BigDecimal>();
       
       returnArrayList = returnBigDecimal.readFile();
       writeToFile.writeFile(returnArrayList);
        
        
    }
    
}
