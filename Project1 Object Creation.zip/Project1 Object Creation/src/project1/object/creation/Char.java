/* Nicholas Johnson
 * 8/25/2018
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Class called Char which works on primitive chars, more specifically 
uses the wrapper class "Character". In this class chars are created and can be added to 
eachother to create strings, which then can also be casted to doubles.
These chars can be casted back into integers and returned as ints. Also works with complex type Char
which can also add to eachother.

 */

package project1.object.creation;

    /*
    Function: Class named Char.
    Author: Nicholas Johnson
    Description: This class we will be dealing with primitive chars
    Inputs: Class creation.
    Outputs: Chars to ints. int to chars. Chars to doubles. Chars to strings.
    */

public class Char
{
    /*
    Function: Data section of char named dataChar. 
    Author:Nicholas Johnson
    Description: This data type is Charater wrapper class for primitive char.
    Inputs: Character created, private, so that only its class members can access it
    Outputs: Chars to ints. int to chars. Chars to doubles. Chars to strings.
    */
    
    private Character dataChar;
   
    /*
    Function: Constructor: Char
    Author: Nicholas Johnson
    Description: Sets data section to null.
    Inputs: Accesses the data section
    Outputs: sets the Character dataChar to null
    */
   
    public Char()
    {
       this.dataChar = null;
    }
    
    /*
    Function: Overloaded Constructor also named Char
    Author: Nicholas Johnson
    Description: Sets the data section of Char class
    Inputs: Parameter of primitive type char named c
    Outputs: Sets the data section to the parameter char c
    */
    
    public Char(char c)
    {
        this.dataChar = c;
    }
    
    
    /*
    Function: Overloaded Constructor: Char
    Author: Nicholas Johnson
    Description: Sets the data section of Char class
    Inputs: Parameter of primitive type int
    Outputs: Sets the data section to the parameter. First cast int c to a char
    */
    
    public Char(int c)
    {
        this.dataChar = (char) c;
    }
    
   
    /*
    Function: Overloaded Constructor also named Char
    Author: Nicholas Johnson
    Description: Sets the data section
    Inputs: Final complex type Char parameter called c
    Outputs: Sets the data section to the parameter c
    */
    
    public Char(final Char c)
    {
        dataChar.equals(c);
        
      
    }
    
    /*
    Function: Overloaded Constructor also named Char
    Author: Nicholas Johnson
    Description: Sets the data section
    Inputs: String parameter called c
    Outputs: sets the data section to the first charcter in the string
    */
    
    public Char(String c)
    {
        this.dataChar = c.charAt(0);
               
    }
    
    /*
    Function: Function named equals
    Author: Nicholas Johnson
    Description: Sets the data section
    Inputs: A parameter is passed. Complex type Char called c
    Outputs: Sets the data section to the parameter Char c
    */
    
    public void equals(final Char c)
    {
       
        dataChar.equals(c);  
    }
    
    /*
    Function: Method: equals
    Author: Nicholas Johnson
    Description: Sets the data section
    Inputs: Parameter of primitive type char called c
    Outputs: Sets the data section to the parameter being passed "c"
    */
    
    public void equals(char c)
    {
        this.dataChar =  c;
    }
    
    /*
    Function: Method/Function: equals
    Author: Nicholas Johnson
    Description: Sets the data section
    Inputs: Parameter of primitive type int called c
    Outputs: Sets the data section to the parameter being passed and casted to a char
    */
    
    public void equals(int c) throws CharException
    {
       if(c >= 32 && c <= 127)
        {
            this.dataChar = (char) c;
        }
       else
       {
           throw new CharException();
       }
     
                
    }
    
    /*
    Function: Accessor Method: toChar
    Author: Nicholas Johnson
    Description: Accesses the data section
    Inputs: No input, but method is called
    Outputs: Returns the data section
    */
    
    public char toChar()
    {
        return this.dataChar;
    }
    
    /*
    Function: Accessor Method: toInt
    Author: Nicholas Johnson
    Description: Accesses the Data section
    Inputs: No input, but method is called
    Outputs: Returns the data section, cast the data section to an int
    */
    
    public int toInt()
    {
        return (int) this.dataChar;
    }
    
    /*
    Function: Accessor Method: toString
    Author: Nicholas Johnson
    Description: Accesses the data section
    Inputs: No input, method is called
    Outputs: Returns the data section as a string
    */
    
    
    @Override
    public String toString()
    {
        return Character.toString(dataChar);
    }
    
    /*
    Function: Accessor Method: toHexString
    Author: Nicholas Johnson
    Description: Accesses the data section
    Inputs: No input, but method is called
    Outputs: Returns the data type has a HexString
    */
    
    public String toHexString()
    {
        
        return Integer.toHexString((int) this.dataChar);
        
    }
    
    /*
    Function: Mutator method: add
    Author: Nicholas Johnson
    Description: Changes the data section
    Inputs: Parameter being passed of primitive char called c
    Outputs: Returns a string from adding the parameter char to the data section char
    */
    
    public String add(char c)
    {
       
        return Character.toString((char) (c + dataChar));
    }
    
    /*
    Function: Method: add
    Author: Nicholas Johnson
    Description: Adds two complex type Chars together and returns a string
    Inputs: The parameter being passed is complex type Char called c
    Outputs: c gets added with the data section and is returned as a String
    */
    
    public String add(final Char c)
    {
        String num = "";
        String retNum;
        num += c.toChar();
        retNum = (num + this.dataChar);
       
        
        return retNum;
        
        
    }
    
    
}
