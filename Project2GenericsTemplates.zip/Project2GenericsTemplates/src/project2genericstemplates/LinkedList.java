/* Nicholas Johnson
 * 9/8/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: LinkedList class. Generic class. This class is able save a list using a node.
This class is also the mother class to the pairlist class. Data section is a node
that takes in Generic type T. This class has functionality to create a list, add/delete
from the list, as well as insert new data to a specific location in the list. This class
can also print the list.
 */
package project2genericstemplates;

/*
Function: Class: LinkedList 
Author: Nicholas Johnson
Description: LinkedList is a generic class T
Inputs: Recieves generic types
Outputs: Puts the input it recieves into a list/node
*/    

public class LinkedList <T>
{

/*
Function: Data section: Generic type Node called Head
Author: Nicholas Johnson
Description: This will be where the data gets saved to
Inputs: Recieves data, Intger/Double/Character/String
Outputs: Turns the data into a list/node
*/    
    
    Node<T> Head = null;
    
    
/*
Function: addNode
Author: Nicholas Johnson
Description: Adds more data to the list
Inputs: Parameter named data: generic type
Outputs: Adds another line to the list/node of what data is equal to
*/        
    
    void addNode(T data)
    {
        if(Head == null)
        {
            Head = new Node();
            Head.Data =  data;
            Head.Next = null;
        }
        else
        {
           Node p = this.Head;
           
           while(p.Next != null)
               p = p.Next;
           
           Node n = new Node();
           n.Data =  data;
           n.Next = null;
           
           p.Next = n;
        }
    }
    
/*
Function: printList
Author: Nicholas Johnson
Description: Prints to output screen the list
Inputs: Void method, no parameters
Outputs: When method is called it prints the Node as a list to output screen
*/    
    
    public void printList()
    {
        Node p = Head;
            
        while(p != null)
        {
            System.out.println(p.Data);
            p = p.Next;
                        
        }
    }
    
    
/*
Function: insert
Author: Nicholas Johnson
Description: inserts new data to the list
Inputs: Two parameters: search, and value. Searches for what the parameter search is equal too
Outputs: Once search finds a match the method will insert what the parameter
    - value is equal too directly behind the search value
*/    
    
    public void insert(T search, T value)
    {
        Node p = Head;
        while(!p.Data.equals(search))
        {
            p = p.Next;
        }
        
        Node n = new Node();
        n.Data = (String) value;
        
        n.Next = p.Next;
        p.Next = n;
    }
    
/*
Function: deleteNode
Author: Nicholas Johnson
Description: Searches and deletes a specific part of the list
Inputs: The parameter search is used to look for a specific part of the list
Outputs: Once the search finds the match of the parameter it will delete that
    - data from the list
*/    
    
    public void deleteNode(T search)
    {
        Node <T> p = this.Head;
        while(!p.Next.Data.equals(search))
        {
            p = p.Next;
        }
        Node delRef = p.Next;
        p.Next = p.Next.Next;
        delRef = null;
    }
    
}
