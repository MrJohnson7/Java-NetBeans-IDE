/* Nicholas Johnson
 * 9/8/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Node class. Generic class. This class has a public default constructor
as well as public data section. This is so the other classes in the program can access
the data section of this class. The data section here stores the node pairs and 
makes it easy to search through a node.
 */
package project2genericstemplates;

/*
Function: Class: Node
Author: Nicholas Johnson
Description: Holds data and is accessible by other classes in program
Inputs: Holds data
Outputs: Holds data
*/    

public class Node<T> 
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Two variables. Node and Generic type
Inputs: Holds data
Outputs: Next will hold Node data, Data will hold generic type data
*/  
    public Node Next;
    public T Data;
    
/*
Function: Node
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs, made public
Outputs: Allows other classes to use the data section
*/  
    
    public Node()
    {
        
    }   
    
}
