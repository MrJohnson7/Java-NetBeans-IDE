/* Nicholas Johnson
 * 9/8/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: PairList class. Generic class. This class is using inheritance by
extending LinkedList<Pair>. PairList has the same functionality that linkedlist has.
This class is able to make a list of pairs through the use of a node used in the linkedlist
class. Has functionality to add/delete a ordered pair from the node, also is able to find 
a certain pair by locating one variable of the ordered pair. This class can also
print the list of pairs.
 */

package project2genericstemplates;


/*
Function: Class PairList
Author: Nicholas Johnson
Description: Extends linkedlist, has linkedlist functionality. Also a Generic class
Inputs: Getting pairs from the pair class
Outputs: Saving the pairs as a list
*/

public class PairList<F, S> extends LinkedList<Pair>
{
    

/*
Function: addPair
Author: Nicholas Johnson
Description: Adds new Pairs to a node
Inputs: Two parameters being passed in called first, and second
Outputs: Parameters being passed in are created through the Pair class, and then 
-added to the node
*/
    
    public void addPair(F first, S second)
    {
       addNode(new Pair(first, second));
    }
    
/*
Function: getFirst
Author: Nicholas Johnson
Description: Getting the first parameter within the pair
Inputs: Parameter second will be used to search for a specific pair
Outputs: Once the parameter is found the method will return the first term of the ordered pair
*/    
    
    public F getFirst(S second)
    {
        Node<Pair> p = Head;
        while(p.Data.getSecond() != second)
        {
            p = p.Next;
        }
       
        return (F) p.Data.getFirst();
        
    }


/*
Function: getSecond
Author: Nicholas Johnson
Description: Getting the second parameter within the pair
Inputs: Parameter first will be used to search for a specific pair
Outputs: Once the parameter is found the method will return the second term of the ordered pair
*/      
    
    public S getSecond(F first)
    {
        Node<Pair> p = Head;
        while(p.Data.getFirst() != first)
        {
            p = p.Next;
        }
       
        return (S) p.Data.getSecond();
        
        
    }
    
/*
Function: deletePair
Author: Nicholas Johnson
Description: Searches for a certain pair from the list and deletes targeted pair
Inputs: Two generic parameter first and second which will be used to search for a pair
Outputs: Once the certain pair is found, it will be deleted from the list/Node
*/    
    
    public void deletePair(F first, S second)
    {
       int count = 0;
       Node <Pair> p = this.Head;
       while(p.Data.getFirst() != first && p.Data.getSecond() != second)
       {
            p = p.Next;
            count++;
       }
       p = this.Head;
       
       for(int i = 0; i < count--; i++)
       {
           p = p.Next;
       }
       Node <Pair> delRef = p.Next;
       p.Next = p.Next.Next;
       delRef = null;
       
    }
    
    
/*
Function: printList
Author: Nicholas Johnson
Description: Prints list to output screen
Inputs: Void method with no parameters
Outputs: When method is called, it will print the list to the output screen
*/    
    
    @Override
    public void printList()
    {
        Node<Pair> p = Head;
            
        while(p != null)
        {
            System.out.println(p.Data.getFirst() + " " + p.Data.getSecond());
            p = p.Next;
                        
        }
    }
    
}
