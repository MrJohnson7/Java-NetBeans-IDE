/* Nicholas Johnson
 * 9/8/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program has been created to save a list of pairs using a linked list
and a specialized version of a linked list called the pairlist. We are not using
an arraylist or a vector to hold the list of pairs, instead we are using a node.
This program works with Generic classes so it works on many types of data including
Strings, Doubles, Charcters, and Integers. This program runs tests on each of the classes
methods. This program also is able to manipulate the List of pairs. Functionality consists
of adding and deleting data to the list as well as inserting new data to a specific location
in the list.
 */
package project2genericstemplates;


public class Project2GenericsTemplates 

{
    
    public static void main(String[] args) 
    {
        System.out.println("LIST OF PAIRS");
        PairList pl = new PairList();
        pl.addPair(1, 2);
        pl.addPair(3, 4);
        pl.addPair(5, 6);
        pl.addPair(7, 8);
        pl.addPair(9, 10);
        pl.printList();
        
        System.out.println("\n" + "Finding the first and second parameters in a pair: ");
        System.out.println("Searches for 6 and gets: " + pl.getFirst(6));
        System.out.println("Searches for 9 and gets: " + pl.getSecond(9));
        System.out.println("Searches for 2 and gets: " + pl.getFirst(2));
        System.out.println("Searches for 1 and gets: " + pl.getSecond(1));
        
       
        System.out.println("\n" + "Deleting pairs  (5, 6) & (7, 8)");
        pl.deletePair(5, 6);
        pl.deletePair(7, 8);
        pl.printList();
        
       
        System.out.println("\n" + "LINKED LIST CLASS");
        LinkedList sample = new LinkedList();
        sample.addNode("1");
        sample.addNode("2");
        sample.addNode("3");
        sample.addNode("4");
        sample.addNode("5");
        sample.addNode("Green");
        sample.addNode("40");
        sample.addNode("30.6");
        sample.addNode('A');
        sample.addNode("5");
        sample.printList();
        System.out.println("\n" + "Inserting 77, 3A, Nick & Deleting 2, 5");
        
        sample.insert("Green", "77");
        sample.insert("3", "3A");
        sample.insert("30.6", "Nick");
        sample.deleteNode("2");
        sample.deleteNode("5");
        sample.printList();
        System.out.println("\n");
        
        System.out.println("THE PAIR CLASS" + "\n" + "Strings/Doubles/Charcters/Integers");
        Pair test = new Pair("Football", 2019);
        System.out.print(test.getFirst() + " , " + test.getSecond() + "\n" );
       
        test.setFirst(40.777);
        System.out.print(test.getFirst() + " , " + test.getSecond() + "\n" );
       
        test.setSecond('A');
        System.out.print(test.getFirst() + " , " + test.getSecond() + "\n" + "\n" );
        
    }
    
}
