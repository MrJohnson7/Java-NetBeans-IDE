/* Nicholas Johnson
 * 9/8/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Pair class, Generic class. This class is able to hold multiple data 
types. Two variables in the data section that hold specific data. This data can also be
changed.
 */

package project2genericstemplates;

/*
Function: Class: Pair
Author: Nicholas Johnson
Description: Generic class that takes two Generic types F and S
Inputs: Saving a list of pairs
Outputs: Printing a list of pairs
*/

public class Pair <F, S>
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Two varaiables
Inputs: Send in pairs of any complex types Intger/Double/Character/String
Outputs: Saves the pairs in these parameters
*/
    
    private F firstParameter;
    private S secondParameter;
    
/*
Function: Working constructor Pair
Author: Nicholas Johnson
Description: Sets the data section
Inputs: Two parameters being passed into method
Outputs: Sets the data section from the parameters being passed
*/
    
    public Pair(F newParameter, S secondNewParameter)
    {
        firstParameter = newParameter;
        secondParameter = secondNewParameter;
    }
    
/*
Function: getFirst
Author: Nicholas Johnson
Description: Returns the data section
Inputs: No input, method does get called
Outputs: Returns one parameter from the data section
*/
    
    public F getFirst()
    {
        return firstParameter;
    }
    
/*
Function: getSecond
Author: Nicholas Johnson
Description: Returns the data section
Inputs: No input, method does get called
Outputs: Returns the second parameter from the data section
*/
    
    public S getSecond()
    {
        return secondParameter;
    }
    
/*
Function: setFirst
Author: Nicholas Johnson
Description: Sets the data section
Inputs: Parameter being passed in called firstSetter
Outputs: Sets the data section to the parameter being passed in
*/    
    
    public void setFirst(F firstSetter)
    {
        firstParameter = firstSetter;
    }
    
/*
Function: setSecond
Author: Nicholas Johnson
Description: Sets the data section
Inputs: Parameter being passed in called secondSetter
Outputs: Sets the data section to the parameter being passed in
*/        
    
    public void setSecond(S secondSetter)
    {
        secondParameter = secondSetter;
    }    
    
    
}
