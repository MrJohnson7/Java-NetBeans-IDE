/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class sorts the data from the array holding 20,000 doubles, the program sorts
the data using the Shell Sort methods.
 */
package project7sorting;


public class ShellSort 
{
/*
Function: Data Section
Author: Nicholas Johnson
Description: Three variables of differnt data types.
Inputs: No inputs.
Outputs: Stores data from the program
*/   
    private double[] dubArray;
    private int itterations;
    private Timer tmr = new Timer();
  
/*
Function: Constructor ShellSort
Author: Nicholas Johnson
Description: Sets the array in the data section
Inputs: No inputs
Outputs: Sets the array of doubles: dubArray to the size of 100.
*/    
    public ShellSort()
    {
        this.dubArray = new double[100];
    }
/*
Function: Woring Constructor: ShellSort
Author: Nicholas Johnson
Description: Sets the data section to the parameter being passed
Inputs: Array of doubles called newArray
Outputs: Sets the data section array to newArray.
*/    
    
    public ShellSort(double[] newArray)
    {
        this.dubArray = newArray;
    }
/*
Function: shellSort
Author: Nicholas Johnson
Description: This method sorts the list by comparing the first value in the array to
the value position at the 1/2 position of the whole array. Swapping numbers if the value on the
left is smaller than the value on the right. When it reaches the end of the array,
the sorting starts over this time comparing the first element to the value position 
at the 1/4 position of the array, repeats the same process. At the end of the program 
it outputs the time it took to sort. 
Inputs: Array of doubles called list, also and int variable called last.
Outputs: Sorts the Array of 20,000
*/    
    
    public void shellSort(double[] list, int last)
    {
        try
        {
        tmr.startTimer();
        Thread.sleep(1000);
        }
        catch(Exception e)
        {
                    
        }
        
        double hold;
        int incre;
        int index;
        
        incre = last / 2;
        
        while(incre != 0)
        {
            for (int curr = incre; curr <= last-1; curr++)
            {
                hold =  list[curr];
                index = curr - incre;
                while(index >= 0 && hold < list[index])
                {
                    //move larger element up the list
                    
                    list[index + incre] = list[index];
                    
                    //fall back one partition
                    
                    index = (index - incre);
                }
                //Insert hold in proper position
                
                list[index + incre] = hold;
                this.itterations++;
            }
            //End of pass-- calculate next increment
            
            incre = incre / 2;
        }
        
        tmr.stopTimer();
        
        System.out.println("Shell Sort Timing: " + "\n" + "Number of iterations: " + 
            this.itterations);
        System.out.println("Micro " + tmr.getMicro());
        System.out.println("Milli " + tmr.getMilli());
        System.out.println("Seconds " + tmr.getSecond() + "\n");
        
    }
    
}
