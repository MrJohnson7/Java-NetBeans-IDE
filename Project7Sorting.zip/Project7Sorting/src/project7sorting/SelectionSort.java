/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class sorts the data from the array holding 20,000 doubles, the program sorts
the data using the Selection Sort methods.
 */
package project7sorting;

public class SelectionSort 
{
/*
Function: Data Section
Author: Nicholas Johnson
Description: Three variables of differnt data types.
Inputs: No inputs.
Outputs: Stores data from the program
*/    
    private double[] dubArray;
    private int itterations;
    private Timer tmr = new Timer();
/*
Function: Constructor Selection Sort
Author: Nicholas Johnson
Description: Sets the array in the data section
Inputs: No inputs
Outputs: Sets the array of doubles: dubArray to the size of 1000.
*/    
    
    public SelectionSort()
    {
        this.dubArray = new double[1000];
    }
/*
Function: Woring Constructor: SelectionSort
Author: Nicholas Johnson
Description:Sets the data section to the parameter being passed
Inputs: Array of doubles called newArray
Outputs: Sets the data section array to newArray.
*/    
    public SelectionSort(double[] newArray)
    {
        this.dubArray = newArray;
    }
/*
Function: minLocation
Author: Nicholas Johnson
Description: This method determines what is the smallest number in the array to be switched
with the pivot position in the selectionSort method.    
Inputs: Array of doubles called list, int varaiables called first and last.
Outputs: Returns an int vaiable mIndex back to the selection sort method.
*/    
    
    public int minLocation(double[] list, int first, int last)
    {
        int mIndex = first;
        
        for(int loc = first + 1; loc <= last; loc++)
            if (list[loc] < list[mIndex])
                mIndex = loc;
        this.itterations++;
        return mIndex;
    }
/*
Function: selectionSort
Author: Nicholas Johnson
Description: Sorts the array of doubles into an order from lowest to highest.
It searches the array marking/ holding a pivot position. When it finds the a smallest
number in the array, than the pivot position these two positions swap places. After these numbers swap
the pivot position is then shifted to the right and the process repeats. 
At the end of the program it outputs the time it took to sort.    
Inputs: Array of doubles called list.
Outputs: Sorts the data in the array from lowest to smallest.
*/    
    
    public void selectionSort(double[] list)
    {
        try
        {
        tmr.startTimer();
        Thread.sleep(1000);
        }
        catch(Exception e)
        {
                    
        }
        
        int mIndex = 0;
        for(int loc = 0; loc < list.length - 1; loc++)
        {
            mIndex = minLocation(list, loc, list.length - 1);
            double tmp = list[loc];
            list[loc] = list[mIndex];
            list[mIndex] = tmp;
            
        }
        tmr.stopTimer();
        
       System.out.println("Selection Sort Timing: " + "\n" + "Number of iterations: " + 
              this.itterations);
       System.out.println("Micro " + tmr.getMicro());
       System.out.println("Milli " + tmr.getMilli());
       System.out.println("Seconds " + tmr.getSecond() + "\n");
    }
    
}
