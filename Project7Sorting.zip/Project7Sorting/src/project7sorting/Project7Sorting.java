/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program uses four different Sort classes to sort an array of 20000
doubles. The object is to determine which Sort class is faster at sorting the array.
The sort classes are Insertion Sort, Selection Sort, Shell Sort, Quick Sort.
 */
package project7sorting;

import java.util.Random;
public class Project7Sorting 
{

    public static void main(String[] args) 
    {
        Random r = new Random();
        double[] dubArray = new double[20000];
   
        
        for(int i = 0; i < dubArray.length; i++)
        {
            dubArray[i] = r.nextDouble() * 1000;
        }
        
        InsertionSort test2 = new InsertionSort();
        test2.insertionSort(dubArray);
        
        SelectionSort test3 = new SelectionSort();
        test3.selectionSort(dubArray);
        
        ShellSort test4 = new ShellSort();
        test4.shellSort(dubArray, dubArray.length);
        
        QuickSort test5 = new QuickSort(dubArray);
        test5.quickSort();
        test5.print();
        
    }
    
}
