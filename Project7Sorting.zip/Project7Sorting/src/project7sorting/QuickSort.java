/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class sorts the data from the array holding 20,000 doubles, the program sorts
the data using the Inserion Sort methods.
 */
package project7sorting;


public class QuickSort 
{
/*
Function: Data Section
Author: Nicholas Johnson
Description: Three variables of differnt data types.
Inputs: No inputs.
Outputs: Stores data from the program
*/    
    private double[] dubArray;
    private int itterations;
    private Timer tmr = new Timer();
    
/*
Function: Working Constructor: QuickSort
Author: Nicholas Johnson
Description: Sets the data section
Inputs: Array of doubles called test.
Outputs: Sets the data section to the array being passed to constructor.
*/    
    
    public QuickSort(double[] test)
    {
        this.dubArray = test;
    }
    
/*
Function: partitiion
Author: Nicholas Johnson
Description: This method determines the pivot position froming swapping two variables 
in the array
Inputs: Two int varables called first and second
Outputs: Return the pivot position to be used in the recursive quickSort method.
*/    
    
    public int partition(int first, int last)
    {
        int pivot;
        int index, smallIndex;
        
        swap(first, (first + last) / 2);
    
        pivot = (int) this.dubArray[first];
        smallIndex = first;
        
        for(index = first + 1; index <= last; index++)
        {
            if(this.dubArray[index] < pivot)
            {
                smallIndex++;
                swap(smallIndex, index);
            }
        }
        
        swap(first, smallIndex);
        return smallIndex;
    }
    
/*
Function: swap
Author: Nicholas Johnson
Description: Swaps two variables
Inputs: Two int variables first and second
Outputs: This method swaps two variables in the array. Swaps two variables
in their positions in the array.
*/    
    
    public void swap(int first, int second)
    {
        double temp;
        
        temp = this.dubArray[first];
        this.dubArray[first] = this.dubArray[second];
        this.dubArray[second] = temp;
    }
    
/*
Function: quickSort
Author: Nicholas Johnson
Description: Starts the timer, and also sends the array "dubArray" to the recursive 
method recQuickSort.    
Inputs: No inputs
Outputs: When called the timer is started, and the recursive method is then activated.
*/    
    
    public void quickSort()
    {
        try
        {
        tmr.startTimer();
        Thread.sleep(1000);
        }
        catch(Exception e)
        {
                    
        }
        recQuickSort(0, this.dubArray.length - 1);
    }
    
/*
Function: recQuickSort
Author: Nicholas Johnson
Description: This method useds a pivot location, this pivot location is important as its
used for sorting. This pivot position is determined in the partition method which
is called from this method. Using recursion this method will swap item from left and right 
if item on right is smaller than item on left these two positions in the array swap.    
Inputs: Two int variables called first and second
Outputs: Sorts the array from lowest to highest
*/    
    
    public void recQuickSort(int first, int last)
    {
        int pivotLocation;
        if(first < last)
        {
            pivotLocation = partition(first, last);
            recQuickSort(first, pivotLocation - 1);
            //this.itterations++;
            recQuickSort(pivotLocation + 1, last);
            //this.itterations++;
                    
        }
        this.itterations++;
        tmr.stopTimer();
    }

/*
Function: print
Author: Nicholas Johnson
Description: This method simply outputs the ittertions as well as the timer calculations.
Inputs: No inputs
Outputs: Outputs the itterations and timer calculations to the screen
*/    
    public void print()
    {
        
        System.out.println("Quick Sort Timing: " + "\n" + "Number of iterations: " + 
            this.itterations);
        System.out.println("Micro " + tmr.getMicro());
        System.out.println("Milli " + tmr.getMilli());
        System.out.println("Seconds " + tmr.getSecond() + "\n");
    }
    
}
