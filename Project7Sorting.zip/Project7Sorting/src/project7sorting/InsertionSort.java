/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class sorts the data from the array holding 20,000 doubles, the program sorts
the data using the Inserion Sort methods.
 */
package project7sorting;


public class InsertionSort 
{
/*
Function: Data Section
Author: Nicholas Johnson
Description: Three variables of differnt data types.
Inputs: No inputs.
Outputs: Stores data from the program
*/    
    
    private double[] dubArray;
    private int itterations;
    private Timer tmr = new Timer();
    
/*
Function: Constructor: Insertion Sort
Author: Nicholas Johnson
Description: Works with the array in the data section
Inputs: No inputs
Outputs: When called, sets the array size to 1000
*/    
    
    public InsertionSort()
    {
        this.dubArray = new double[1000];
    }
/*
Function: Working Constructor: Insertion Sort
Author: Nicholas Johnson
Description: Sets the data section of the array
Inputs: double array called newArray
Outputs: Sets the data section to newArray
*/    
    
    public InsertionSort(double[] newArray)
    {
        this.dubArray = newArray;
    }
/*
Function: insertionSort
Author: Nicholas Johnson
Description: This method sorts the array of 20000 by searching through each element
position in array. Sorts from left to right. If the right value is less then the left value then
those to places switch, and will continue to switch with the previous positions in 
the array untill the left value is smaller then the right value. At the end of the program
it outputs the time it took to sort.    
Inputs: Array of doubles called list
Outputs: Sorts the array list a puts them in the correct order from lowest to highest value.
*/    
    
    public void insertionSort(double[] list)
    {
        try
        {
        tmr.startTimer();
        Thread.sleep(1000);
        }
        catch(Exception e)
        {
                    
        }
        
        int location, temp;
        
        for (int foo = 1; foo < list.length - 1; foo++)
        {
            if(list[foo] < list[foo - 1])
            {
                temp = (int) list[foo];
                location = foo;
                do
                {
                    list[location] = list[location -1];
                    this.itterations++;
                    location--;
                }
                while (location > 0 && list[location -1] > temp);
                list[location] = temp;
                
            }
            
        }
        tmr.stopTimer();
        
       System.out.println("Insertion Sort Timing: " + "\n" + "Number of iterations: " + 
              this.itterations);
       System.out.println("Micro " + tmr.getMicro());
       System.out.println("Milli " + tmr.getMilli());
       System.out.println("Seconds " + tmr.getSecond() + "\n");
    }
    
}
