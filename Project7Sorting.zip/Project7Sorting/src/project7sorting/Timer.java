/* Nicholas Johnson
 * 11/17/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class is a stop watch. Basic functionality of starting a timer 
and stopping a timer. It saves the time and returns time in: Micro, Milli, Seconds.
 */
package project7sorting;

public class Timer 
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Stores data.
Inputs: No inputs
Outputs: Stores data in a double data type variable.
*/    
    double count = 0;
    
/*
Function: Constructor: Timer
Author: Nicholas Johnson
Description: Empty Constructor
Inputs: No inputs
Outputs: Make a instance of this class to use its functionality
*/    
    public Timer()
    { 
       
    }
    
/*
Function: startTimer
Author: Nicholas Johnson
Description: Starts the timer.
Inputs: No inputs.
Outputs: When called a timer is started. And saved as a double.
*/    
    public void startTimer()
    {
        count = System.nanoTime();
    }
    
/*
Function: stopTimer
Author: Nicholas Johnson
Description: Stops the timer.
Inputs: No inputs
Outputs: When called the timer stops using a long data type variable. And saved into
the count variable.
*/    
    public void stopTimer()
    {
        long stopCount = System.nanoTime();
        count = stopCount - count;
    }
    
/*
Function: getMilli
Author: Nicholas Johnson
Description: Turns the count variable into milliseconds.
Inputs: No inputs
Outputs: Returns the count variable divided by 1000000
*/    
    public double getMilli()
    {
        return count / 1000000.0; 
    }
    
/*
Function: getMicro
Author: Nicholas Johnson
Description: Turns the count variable into macroseconds.
Inputs: No inputs
Outputs: Returns the count variable divided by 1000
*/    
    public double getMicro()
    {
        return count / 1000.0;
    }
    
/*
Function: getSecond
Author: Nicholas Johnson
Description: Turns the count varaiable into seconds.
Inputs: No inputs
Outputs: Returns the count variable divided by 1000000000.0
*/    
    public double getSecond()
    {
        return count / 1000000000.0; 
    }
    
}
