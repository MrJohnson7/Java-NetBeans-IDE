/* Nicholas Johnson
 * 9/22/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Stack class is using inhertance from the Doubly Linked list class
This class allows to add, retrieve, and delete data from a list with the use nodes.
This class is also the mother class to the RPNCalculator class.
 */
package project3doublylinkedlists;

/*
Function: Class: Stack
Author: Nicholas Johnson
Description: Allows us to create and manipulate a Stack/list
Inputs: Takes in Double/Integer/Character/String
Outputs: A Stack/ List
*/  

public class Stack <T> extends DoublyLinkedList
{
    
/*
Function: push
Author: Nicholas Johnson
Description: Pushes element onto the stack
Inputs: Complex type T called elem
Outputs: Adds to the stack
*/  
    
    public void push(T elem)
    {
        this.addToEnd(elem);
    }
    
/*
Function: peek
Author: Nicholas Johnson
Description: Lets us see whats on top of the Stack
Inputs: No input, is directly linked to the stack
Outputs: Return whats at top of the stack
*/      
    
    public T peek()
    {
       if (this.Head != null)
       {
           return (T) this.Head.Data;
       }
       return null;
       
    }
    
/*
Function: pop
Author: Nicholas Johnson
Description: Deletes data
Inputs: No input, is directly linked to the stack
Outputs: Deletes the top of the Stack
*/  
    
    public T pop()
    {
       Node<T> temp = new Node<T>();
       temp.Data = (T) Head.Data;
       
       if (Head.Data != null)
       {
          Head = Head.Next;
          Tail.Prev = null;
          return (T) temp.Data;
       }
       return null;
    }
    
}