/* Nicholas Johnson
 * 9/22/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This is a doubly linked class that allows us to use stacks and queues to hold
a list of Generic types. Using stacks we are able to create an RPN calculator that 
takes in a String and is able to do math calculations. Here in main I have some code that 
tests my code in the RPNCalculator class as well the Stack class.
 */
package project3doublylinkedlists;


public class Project3DoublyLinkedLists 
{

    
    public static void main(String[] args) 
    {
        System.out.println("RPN CLASS: " + "10 + 1 = 11 || 11 * 2 = 22 || 22 - 1 = ANSWER = 21" + "\n");
        RPNCalculator equation = new RPNCalculator("10 1 + 2 * 1 -");
        System.out.println("equation: " + equation.getString());
        equation.splitString();
        System.out.println("\n");
        
        System.out.println("RPN CLASS: " + "1 + 1.5 = 2.5 || 2.5 * 2 = 5 || 5 - 1 = ANSWER = 4" + "\n");
        RPNCalculator equation2 = new RPNCalculator("1 1.5 + 2 * 1 -");
        System.out.println("equation2: " + equation2.getString());
        equation2.splitString();
        System.out.println("\n");
        
        System.out.println("STACK CLASS...");
        Stack s = new Stack();
        s.push(3);
        s.push(3);
        s.push(3);
        s.push(7);
        s.printList();
        System.out.println("Pop the stack: ");
        s.pop();
        s.printList();
        System.out.println("\n");
        
        System.out.println("DOUBLY LINKED CLASS...");
        DoublyLinkedList test = new DoublyLinkedList();
        test.addNode(1);
        test.addNode(2);
        test.addNode(3);
        test.addNode(4);
        test.printList();
        System.out.println("Printing backwards...");
        test.printBackward();
        System.out.println("Get front...");
        System.out.println(test.getFront()+ "");
        System.out.println("Printing backwards...");
        test.insert(3, 7);
        System.out.println("Inserting a 7 to the list");
        test.printList();
    }
    
}
