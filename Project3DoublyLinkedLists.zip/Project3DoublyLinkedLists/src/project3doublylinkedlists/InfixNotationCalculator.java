/* Nicholas Johnson
 * 9/22/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class will rearrange a String so that will be a postfix equation
instead of an infix equation, then saved as a String.
 */
package project3doublylinkedlists;


public class InfixNotationCalculator <T> extends RPNCalculator
{
    
/*
Function: Data Section
Author: Nicholas Johnson
Description: Keeps count
Inputs: Data section
Outputs: Data section
*/       
    
    private int Count;

/*
Function: Constructor: InfixNotationCalculator
Author: Nicholas Johnson
Description: Sends new string to mother constructor
Inputs: String variable called newString
Outputs: Sets the data section of RPN to the string being passed in
*/       

    public InfixNotationCalculator(String newString) 
    {
        super(newString);
    }
    
/*
Function: infixToPostfix
Author: Nicholas Johnson
Description: Changes the contents of the String from a infix to a postfix
Inputs: String variable called expression
Outputs: Returns the String as a postfix
*/       
       
    public String infixToPostfix(String expression)
    {
        String postfix = " ";
        String[] tokens = expression.split(postfix);
        String token = null;
        while(expression != token)
        {
            if (isOperand(token))    
                postfix += token + " ";
            else if (token == "(")
                this.push(token);
            else if (token == ")")
            {
                String topToken = (String) this.pop();
                while (topToken != "(")
                {
                    postfix += topToken + " ";
                    topToken = (String) this.pop();
                }
            }
            else
            {
                while (this.Count > 0 && precedence((String) this.peek()) >= precedence(token))
                {
                    postfix += this.pop() + " ";
                }
                    this.push(token);
            }
        }
        while (this.Count > 0)
            postfix += this.pop() + " ";
            

        return postfix;
    }

/*
Function: doPrecedence
Author: Nicholas Johnson
Description: Changes the String around
Inputs: Two String variables named token and postfix
Outputs: Returns postfix after rearranging the String differently
*/       
    
    public String doPrecedence(String token, String postfix)
    {           
        if (precedence(token) > precedence((String) this.peek()))
        {
            this.push(token);
        }
        else if (precedence(token) == precedence((String) this.peek()))
        {
            postfix += this.pop() + " ";
            this.push(token);
        }
        else if (precedence(token) < precedence((String) this.peek()))
        {
            postfix += this.pop() + " ";    
        }
           
            return postfix;
        }
    

/*
Function: precedence
Author: Nicholas Johnson
Description: Determines the sign of the String and returns a number based on the value
    of the math sign.
Inputs: String x which holds a 
Outputs: Returns an int variable based on the sign of String x
*/   
    
    public int precedence(String x)
    {
        if ("+".equals(x) || "-".equals(x))
            return 1;
        else if ("*".equals(x) || "/".equals(x) || "%".equals(x) )
            return 2;
        else if ("^".equals(x))
            return 3;
        else
            return 0;
    }
    
/*
Function: isOperator
Author: Nicholas Johnson
Description: Checks to see if the String contains an operator
Inputs: String variable called c
Outputs: Returns true or false depending if there was a match found
*/       
    
    public boolean isOperator(String c)
    {
        return "+".equals(c) || "-".equals(c) || "*".equals(c) || "/".equals(c) 
            || "^".equals(c) || "(".equals(c) || ")".equals(c);
    }
    
/*
Function: isOperand
Author: Nicholas Johnson
Description: Checks for an Operand
Inputs: String variable named s
Outputs: Returns true if operand is found within the string, and false if
    operand is not found in the String.
*/     
    
    public boolean isOperand(String s)
    {
        if(!isOperator(s) && !")".equals(s) && !"(".equals(s))
            return true;
        else
            return false;
    }
}
