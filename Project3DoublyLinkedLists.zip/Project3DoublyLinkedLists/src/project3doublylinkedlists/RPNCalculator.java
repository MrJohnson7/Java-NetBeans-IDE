/* Nicholas Johnson
 * 9/22/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: RPN calculator is using inheritance from the Stack class. This class is
used to calculate equations, through the use of nodes and the Stack class.
 */
package project3doublylinkedlists;

/*
Function: Class RPNCalculator
Author: Nicholas Johnson
Description: Using Stack class inhertance
Inputs: Takes in a String to calculate
Outputs: A RPN calculation
*/  

public class RPNCalculator <T> extends Stack
{
    
/*
Function: Data Section
Author: Nicholas Johnson
Description: String called parseString, int called stackCount
Inputs: ParseString is passed in, stackCount keeps track of how many math signs 
    there are. For example, "+, *, -, /"
Outputs: A calculation in the String
*/      
    private String parseString;
    private int stackCount;
    
/*
Function: Working Constructo: RPNCalculator
Author: Nicholas Johnson
Description: Takes in a String
Inputs: String called newString
Outputs: Sets the data section to the parameter being passed in.
*/      
    
    public RPNCalculator(String newString)
    {
        this.parseString = newString;
    }
    
/*
Function: Accessor method: getString
Author: Nicholas Johnson
Description: Is able to access the data section
Inputs: No inputs
Outputs: Returns the data section parseString
*/      
    
    public String getString()
    {
        return this.parseString;
    }
    
/*
Function: splitString
Author: Nicholas Johnson
Description: This method gets the String in the data section and parses out each token as well 
    as gets rid of the unwanted whitespaces in the String. Using a for loop to look for
    the math signs, once the math sign is found, Save the math sign as a Charcter and whatever
    was before the math sign save in a String using the count and reference variables as the parameters 
    to use subString functionality. If the String saved is more than or equal to three spaces in length, 
    use another for loop to determine if there is a white space which indicates there 
    is Two strings to split up. Push the Strings on the stack then push the math signs. 
    Count variable keeps track of where the Sub String ends, and the refernce varaiable 
    keeps track of where the sub string begins. Data section stackCount keeps track 
    of how many math signs there are and also how many calculations will be done.
Inputs: No inputs, does work directly with the data section parseString
Outputs: Seperate the String into many strings and push onto the Stack
*/      
    
    public void splitString()
    {
        int count = 0;
        int reference = 0;
        String numbers;
        
        for(int i = 0; i < parseString.length(); i++)
        {
            if(parseString.charAt(i) == '+' || parseString.charAt(i) == '-' ||
                    parseString.charAt(i) == '/' || parseString.charAt(i) == '*')
            {
                numbers = parseString.substring(reference, count).trim();
                
                if(numbers.length() >= 2)
                {
                    String[] seperate = numbers.split("\\s");
                    
                    for(String cut : seperate)
                    {
                        this.push(cut);
                    }
                    Character sign = parseString.charAt(i);
                    this.push(sign);
                    stackCount++;
                    reference = count;
                    count++;
                    reference++;
                }
                
                else
                {
                Character sign = parseString.charAt(i);
                this.push(numbers);
                this.push(sign);
                stackCount++;
                reference = count;
                count++;
                reference++;
                }
                
            }
            else
            {
                 count++;
            }
        }
        mathCalc();
    }
    
/*
Function: mathCalc
Author: Nicholas Johnson
Description: Through the use of a for loop Im able pop off the first two strings
    and convert them into doubles, then I pop of the the third node that contains the 
    math sign, with these three variables being popped off, I can calculate using a switch 
    statement on the math sign. In order for the loop to work again I have to cast the 
    answer back to a String and push the answer back onto the stack. Process repeats untill
    the list is empty then push the answer to the Stack.
Inputs: This methos is called from splitString method
Outputs: Pops and pushes data from the stack, to get a final answer RPN calculation
*/         
    
    public void mathCalc()
    {
        for(int i = 0; i < stackCount; i++)
        {
           
           String num = (String) this.pop();
           double number1 = Double.parseDouble(num);
           String num2 = (String) this.pop();
           double number2 = Double.parseDouble(num2);
           Character sign = (Character) this.pop();
           
           switch(sign)
           {
               case '+':
                   double additionValue = number2 + number1;
                   String bacToStack = Double.toString(additionValue);
                   this.insertAt(0, bacToStack);
                   break;
               case '-':
                   double subValue = number2 - number1;
                   String backToStack = Double.toString(subValue);
                   this.push(backToStack);
                   break;
               case '*':
                   double multValue = number2 * number1;
                   String bakToStack = Double.toString(multValue);
                   this.insertAt(0, bakToStack);
                   break;
               case '/':
                   double divideValue = number2 / number1;
                   String backToStak = Double.toString(divideValue);
                   this.insertAt(0, backToStak);
                   break;
           }
        }
        System.out.print("Answer: ");
        this.printList();
    }
   
}
 