/* Nicholas Johnson
 * 11/3/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class reads data from a file and loads the data read to hash table.
*/
package project6hashtables;

import java.io.BufferedReader;
import java.io.FileReader;

/*
Function: Class: HashFileReader
Author: Nicholas Johnson
Description: Simple file reader
Inputs: none
Outputs: Hash Table data structure
*/  

public class HashFileReader extends HashTable
{
    
/*
Function: readFile
Author: Nicholas Johnson
Description: This method reads a file and loads each line into a hash table
Inputs: No inputs
Outputs: When this method is called from main it reads a file called HashData, 
When each line is read is then sent to the hash method in the hashtable class.    
*/
    
    public void readFile()
    {
        FileReader fr = null;
        BufferedReader br = null;

        try
        {
            fr = new FileReader("HashData.txt");
            br = new BufferedReader(fr);
            String line;
            
            while((line = br.readLine()) != null)
            {
                this.hash(line);
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        finally
        {
            try
            {
                br.close();
                fr.close();
            }
            
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }
           
        }
    }
    
}
