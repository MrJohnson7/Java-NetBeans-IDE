/* Nicholas Johnson
 * 11/3/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This project creates hash tables and loads data from a file into a hash 
table.
*/
package project6hashtables;

import java.util.Scanner;

/*
Function: Project 6 Hash Tanles
Author: Nicholas Johnson
Description: This project creates hash tables and loads data from a file into a hash 
table.
Inputs: none
Outputs: none
*/    

public class Project6HashTables 
{
    
/*
Function: main 
Author: Nicholas Johnson
Description: In main there is first some hash table testing working with double data
types. It then counts how many times the number 123 is in the hash table. Then there 
is a user input PHONE NUMBER APPLICATION that loads data from a file and the user is able
search for a phone number in the hash table.    
Inputs: The user will input a name/ string to search for in the hash table
Outputs: Returns the name of the person, their phone number, their hash code, and
also the position in the list where the phone number is held.
*/        
    
    public static void main(String[] args) 
    {
        HashTable test = new HashTable();
        test.hash(16);
        test.hash(21);
        test.hash(12);
        test.hash(123);
        test.hash(19);
        test.hash(200);
        test.hash(123);
        test.hash(77);
        test.hash(33);
        test.hash(99);
        test.hash(100);
        test.hash(123);
        test.hash(123);
        
        System.out.println("HASH TABLE TESTING");
        test.printTable();
        int count = test.search(123);
        System.out.println("The number of times the number 123 appears: ");
        System.out.println(count);
        System.out.println("/////////////////////////////////////////////////////");
        
        HashFileReader testn = new HashFileReader();
        testn.readFile();
        ////testn.printTable();
       
        System.out.println("*************PHONE NUMBER APPLICATION: **************");
        System.out.print("Would you like to look up a phone number? <Y/N> ");
        Scanner input = new Scanner(System.in);
        String userDecision = input.nextLine();
        
        while(userDecision.equals("Y") || userDecision.equals("y"))
        {
            System.out.println("Please enter a name: ");
            String name = input.nextLine();
            System.out.println(testn.searchFile(name) + "\n");
            System.out.print("Would you like to look up another number? ");
            userDecision = input.nextLine();
        }
        
        System.out.println("GoodBye.");
    }
    
}
