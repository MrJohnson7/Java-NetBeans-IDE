/* Nicholas Johnson
 * 11/3/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: Node class. Generic class. This class has a public default constructor
as well as public data section. This is so the other classes in the program can access
the data section of this class. The data section here stores the nodes, and other data
types which makes it easy to search through a node.
*/
package project6hashtables;


public class Node <T>
{
/*
Function: Data section
Author: Nicholas Johnson
Description: Three variables. Nodes and Generic type
Inputs: Holds data
Outputs: Reference - will hold double data type. Next - will hold Node data.
Data - will hold generic type data
*/  
    public T Data;
    public double Reference;
    
    public Node Next;
    
/*
Function: Node
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs, made public
Outputs: Allows other classes to use the data section
*/  
    
    public Node()
    {
        
    } 
    
/*
Function: Node
Author: Nicholas Johnson
Description: Overloaded Constructor
Inputs: T value 
Outputs: Sets Data to the parameter value
*/    
    
    public Node(T value)
    {
        this.Data = value;
    }
    
/*
Function: Node
Author: Nicholas Johnson
Description: Overloaded Constructor
Inputs: T value, double hashVal
Outputs: Sets Data to the parameter value, Sets reference to the hashVal parameter
*/    

    public Node(T value, double hashVal) 
    {
        this.Data = value;
        this.Reference = hashVal;
    }
 
    
}
