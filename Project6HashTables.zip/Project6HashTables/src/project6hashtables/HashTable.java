/* Nicholas Johnson
 * 11/3/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This class is able to create hash tables.
*/
package project6hashtables;

import java.util.ArrayList;

/*
Function: Class: HashTable
Author: Nicholas Johnson
Description: This class creates hash table data structures
Inputs: Works with doubles and strings
Outputs: Sends the double and Strings into a hash table
*/

public class HashTable <T>
{
    
/*
Function: Data section
Author: Nicholas Johnson
Description: An array list of linked list
Inputs: Strings or doubles
Outputs: Creates the hash table 
*/    
    private ArrayList<LinkedList<T>> table; 
    
/*
Function: HashTable
Author: Nicholas Johnson
Description: Constructor
Inputs: No inputs
Outputs: Sets the table size to 50.
*/    
    public HashTable()
    {
        this.table = new ArrayList<LinkedList<T>>(50);
    }
    
/*
Function: HashTable
Author: Nicholas Johnson
Description: Overloaded constructor
Inputs: Int variable called tableSize
Outputs: Sets the table size to the variable tableSize
*/    
    public HashTable(int tableSize)
    {
        this.table = new ArrayList<LinkedList<T>>(tableSize);
    }
    
/*
Function: hash
Author: Nicholas Johnson
Description: This method creates a hash table for the file HashData file. When a
String gets sent to this method it takes the hash val of only the charcters in the
String by modulous 53. If the table size is 0 then it adds a linked list into
that table position. It adds a node of the key and hashVal to the linked list.
If two Strings have the same hash val then we add another node to that linked list
with the same hash val. If there isnt any identical hash val then we add another linkedlist
to the next open space in the array list.
Inputs: String parameter called key.
Outputs: This String is sent to the arraylist of linkedlists.
*/
    
    public void hash(String key)
    {
      
       String seperateChars = key.replaceAll("[^a-zA-Z]", "");
       double hashVal = (sumAscii(seperateChars) % (53));
      
        if(table.size() == 0)
            {
             LinkedList list = new LinkedList();
             list.Head = new Node(key, hashVal);
             table.add(list);
             return;
            }
        else
        {
            for (int i = 0; i <= table.size()-1;i++)
            {
                if(table.get(i).Head.Reference == hashVal)
                {
                    Node temp = new Node(key,hashVal);
                    table.get(i).addNode((T)temp.Data);
                    return;
                }
            }
            LinkedList elseList = new LinkedList();
            elseList.Head = new Node(key, hashVal);
            table.add(elseList);               
        }
    }
    
/*
Function: sumAscii
Author: Nicholas Johnson
Description: Turns Strings into their int ascii value.
Inputs: String parameter called s
Outputs: Returns the ascii value of the String
*/    
    
     public int sumAscii(String s)
    {
        int sum = 0;
        for(int i = 0; i <s.length(); i++)
        {
            sum += (int) (s.charAt(i));
        }
         return sum;
    }
    
/*
Function: hash
Author: Nicholas Johnson
Description: This hash method works with primitive double data types. We create a     
hash value by modulous the value by the table size+1. If the table size is 0 then 
it adds a linked list into that table position. It adds a node of the key and hashVal 
to the linked list. If two Strings have the same hash val then we add another node 
to the linked list with the same hash val. If there isnt any identical hash val then 
we add another linkedlist to the next open space in the array list.     
Inputs: double parameter called value.
Outputs: Creates a node to one of the linked list inside the arraylist.
*/    
    
    public void hash(double value)
    {
        int hashVal =  (int)(value % (table.size()+1));
        if(table.size() == 0)
        {
            LinkedList list = new LinkedList();
            list.Head = new Node(value, hashVal);
            table.add(list);
            return;
        }
        else
        {
            for (int i = 0; i <= table.size()-1;i++)
            {
                if(table.get(i).Head.Reference == hashVal)
                {
                    Node temp = new Node(value,hashVal);
                    table.get(i).addNode((T)temp.Data);
                    return;
                }
            }
            LinkedList elseList = new LinkedList();
            elseList.Head = new Node(value, hashVal);
            table.add(elseList);               
        }
    }
    
/*
Function: printTable
Author: Nicholas Johnson
Description: This method prints the table with the use of the printList method
in our linked list class.    
Inputs: No inputs.
Outputs: Prints the hash table to the screen
*/
    
    public void printTable()
    {
        for(int i = 0; i < table.size(); i++)
        {
            table.get(i).printList();
            System.out.println("end of list");
        }
        System.out.println("end of table");
    }
    
/*
Function: search
Author: Nicholas Johnson
Description: This method searches through table looking for a specific number. 
The variable value gets turned into a node so it can be compared to a node in the linked list.
When that number is found the count variable gets incremented by 1. The program returns
the variable count.
Inputs: double variable called value.
Outputs: Returns the count vraiable at the end of the method.
*/    
    
    public int search(double value)
    {
        Node n = new Node(value);
        int count = 0;
        for(int i = 0; i < this.table.size(); i++)
        {
            Node p = table.get(i).Head;
            while(p != null)
            {
                if(p.Data.equals(n.Data))
                {
                     count++;
                }
                 p = p.Next;
            }
          
        }
        return count;
    }

/*
Function: searchFile
Author: Nicholas Johnson
Description: This method searches the hash table created from the hashdata file.
The for loop reads through the arraylist, with a nested while loop that reads
through the linkedlist. By casting the node into a string and splitting the string
to just read the charcters, I compare if the names match. When the names do match
the original string gets returned with the name and the phone number, as well as the hash
value, and the position it sits in the linked list.   
Inputs: String parameter called val
Outputs: Return the name, phone number, hash value, and position in the linked list.
If name is not found then it returns the String called nameNotFound.
    
*/    
    
    public String searchFile(String val)
    {
        String nameNotFound = "Sorry this name was not found";
        int count = 0;
        String rename;
        String seperateChars;
        
        for(int i = 0; i < this.table.size(); i++)
        {
            Node p = table.get(i).Head;
            
            while(p != null)
            {
                rename = p.Data.toString();
                seperateChars = rename.replaceAll("[^a-zA-Z]", "");
                
                if(seperateChars.equals(val))
                {
                    return (rename + " (" + table.get(i).Head.Reference + " - " +  count +  ")");
                }
                count++;
                p = p.Next;
            }
            
          count = 0;
        }
        return nameNotFound;
    }
}




/*
    public String searchFile(String val) //Hashing...
    {
        String nameNotFound = "Sorry this name was not found";
        int count = 0;
        String rename;
        String seperateChars;
        //table.get(hashVal).Head.Reference != -1
        int hashVal = (sumAscii(val) % (53));
        
        Node t = table.get(hashVal).Head;
        while(t != null)
        {
            rename = t.Data.toString();
            seperateChars = rename.replaceAll("[^a-zA-Z]", "");
            
            if(seperateChars.equals(val))
            {
                return (rename + " (" + table.get(hashVal).Head.Reference + " - " +  count +  ")");
            }
            count++;
            t = t.Next;
        }

        return nameNotFound;
    }
*/
