/* Nicholas Johnson
 * 12/12/2019
 * Data Structurs: CSIS-211
 * Student ID: 0505878
Description: This program creates an array, turns the array into a binary tree,
turns that binary tree back into an array representation of the binary tree, and 
sorts the array using a heap sort.
 */
package finalproject;

import java.util.Random;


public class FinalProject 
{

    
    public static void main(String[] args) 
    {
       Random r = new Random();
       int[] intArray = new int[63];
       for(int i = 0; i < intArray.length; i++)
       {
            intArray[i] = r.nextInt(50);
       }
        
       //System.out.println("Binary Tree repesentation of Array: ");
       Heap test2 = new Heap(intArray);
       System.out.println("Array Representation of the Binary Tree: ");
       test2.toHeap();
       test2.sort(intArray);
       System.out.println("Heap Sort Algorithm: ");
       test2.printArray();
        
        
        
    }
    
}
